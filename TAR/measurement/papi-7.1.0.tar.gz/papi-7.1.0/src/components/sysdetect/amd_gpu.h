#ifndef __AMD_GPU_H__
#define __AMD_GPU_H__

void open_amd_gpu_dev_type( _sysdetect_dev_type_info_t *dev_type_info );
void close_amd_gpu_dev_type( _sysdetect_dev_type_info_t *dev_type_info );

#endif /* End of __AMD_GPU_H__ */
