from pyextrae.common.extrae import *

TracingLibrary = "libseqtrace.so"

startTracing( TracingLibrary, True )
