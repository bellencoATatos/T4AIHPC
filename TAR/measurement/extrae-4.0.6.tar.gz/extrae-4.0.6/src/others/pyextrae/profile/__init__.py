from pyextrae.common.extrae import *

startProfiling()
