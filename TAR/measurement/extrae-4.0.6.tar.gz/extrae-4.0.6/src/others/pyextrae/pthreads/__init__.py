from pyextrae.common.extrae import *

TracingLibrary = "libpttrace.so"

startTracing( TracingLibrary )
