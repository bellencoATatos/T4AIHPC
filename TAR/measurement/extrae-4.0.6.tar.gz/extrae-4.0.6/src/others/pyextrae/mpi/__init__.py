from pyextrae.common.extrae import *

TracingLibrary = "libmpitrace.so"

startTracing( TracingLibrary )
