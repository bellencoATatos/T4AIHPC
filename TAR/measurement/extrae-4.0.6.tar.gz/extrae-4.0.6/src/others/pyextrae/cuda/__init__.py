from pyextrae.common.extrae import *

TracingLibrary = "libcudatrace.so"

startTracing( TracingLibrary )
