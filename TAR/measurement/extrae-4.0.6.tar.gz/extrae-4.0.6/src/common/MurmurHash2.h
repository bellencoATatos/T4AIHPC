#pragma once

unsigned int MurmurHash2 ( const void * key, int len, unsigned int seed );

