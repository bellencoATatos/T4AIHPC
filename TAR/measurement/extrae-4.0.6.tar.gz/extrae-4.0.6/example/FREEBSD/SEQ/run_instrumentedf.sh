#!/bin/sh

source @sub_PREFIXDIR@/etc/extrae.sh

export EXTRAE_CONFIG_FILE=extrae.xml

./pi_instrumentedf
