#!/bin/bash

source @sub_PREFIXDIR@/etc/extrae.sh

${EXTRAE_HOME}/bin/extrae -config extrae.xml ./pi_forked
