#!/bin/bash

${EXTRAE_HOME}/bin/mpi2prv set-0/*.mpit -o TRACE.prv -s TRACE.sym -e write_all_mtt
