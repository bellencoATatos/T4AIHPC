#!/bin/bash

@sub_PREFIXDIR@/bin/mpi2prv set-0/*.mpit -o TRACE.prv -s TRACE.sym -e write_bw
