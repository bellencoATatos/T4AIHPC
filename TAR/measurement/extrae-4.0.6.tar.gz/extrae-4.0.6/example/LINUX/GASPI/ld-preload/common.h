#ifndef _BENCH_COMMON_H_
#define _BENCH_COMMON_H_

#include <stdio.h>
#include <stdlib.h>
#include <GASPI.h>
#include <GASPI_Ext.h>

int start_bench (int);

void end_bench (void);


#endif //_BENCH_COMMON_H_
