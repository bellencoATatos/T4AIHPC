.. _cha:wholeXML:

An example of |TRACE| XML configuration file
============================================

.. highlight:: xml

.. literalinclude:: ./xml/extrae.xml
