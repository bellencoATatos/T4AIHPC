.. Extrae documentation master file, created by
   sphinx-quickstart on Wed Oct 26 10:26:00 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.
.. _extrae(1):


Extrae documentation
====================

.. toctree::
  :maxdepth: 2
  :numbered:
  
  quick-guide
  introduction
  configure-installation
  xml
  api
  merge
  online
  examples
  
  wholeXML
  envvars
  pnmpi
  regression-tests
  overhead
  FAQ
  submit-bug
  instrumented-routines


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. toctree::
  :hidden:

  see-also
