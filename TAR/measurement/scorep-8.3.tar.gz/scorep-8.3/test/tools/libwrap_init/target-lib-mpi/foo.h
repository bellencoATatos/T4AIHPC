#include <mpi.h>

#ifdef __cplusplus
extern "C"
{
#endif

void
foo_mpi_broadcast_test( int* foo,
                        int  root );

#ifdef __cplusplus
};
#endif
