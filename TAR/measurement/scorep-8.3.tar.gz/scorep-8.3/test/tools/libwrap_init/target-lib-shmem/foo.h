#ifdef __cplusplus
extern "C"
{
#endif

void
foo_shmem_test( void );

#ifdef __cplusplus
};
#endif
