/*
 * CoreFreq (C) 2015-2023 CYRIL COURTIAT
 * Contributors: Andrew Gurinovich ; CyrIng
 * Licenses: GPL2
 */

extern void JsonSysInfo(RO(SHM_STRUCT)*) ;
