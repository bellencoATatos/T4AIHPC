#!/usr/bin/env bash

autoreconf --install
