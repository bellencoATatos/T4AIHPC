This Visual Studio Project creates a static version of the OTF2 library.
Visual Studio 2015 or higher is required to compile the library. The built
version is only tested for reading traces. SIONlib is not supported at all.
