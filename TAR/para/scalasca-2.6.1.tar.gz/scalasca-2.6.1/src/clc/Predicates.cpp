/****************************************************************************
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2022                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#include <config.h>

#include "Predicates.h"

#include <pearl/CommSet.h>
#include <pearl/MpiCollEnd_rep.h>
#include <pearl/MpiComm.h>
#include <pearl/Region.h>

using namespace pearl;


/**
 *  Returns TRUE if the MPI_COLLECTIVE_END event is on the
 *  root process of a collective operation.
 **/
bool
isOnRoot(const Event& event,
         uint32_t     globalRank)
{
    const CommSet& commSet        = event->getComm()->getCommSet();
    const uint32_t rootLocalRank  = event->getRoot();
    const uint32_t rootGlobalRank = commSet.getGlobalRank(rootLocalRank);

    return (globalRank == rootGlobalRank);
}


bool
isLogicalSend(const Event& event,
              int          rank)
{
    // Obviously, (non-)blocking SEND events are also logical sends
    if (event->isOfType(GROUP_SEND))
    {
        return true;
    }

    event_t type = event->getType();
    if (type == MPI_COLLECTIVE_BEGIN)
    {
        const Event& end = event.endptr();

        // No synchronization on self-like communicators, thus no logical send
        if (end->getComm()->getSize() == 1)
        {
            return false;
        }

        MpiCollEnd_rep& endRep = event_cast< MpiCollEnd_rep >(*end);
        switch (native_value(endRep.getCollType()))
        {
            // CASE 1: Barrier, N-to-N communication, and prefix reduction
            case CollectiveOpType::ALLGATHER:
            case CollectiveOpType::ALLGATHERV:
            case CollectiveOpType::ALLREDUCE:
            case CollectiveOpType::ALLTOALL:
            case CollectiveOpType::BARRIER:
            case CollectiveOpType::EXSCAN:
            case CollectiveOpType::REDUCE_SCATTER:
            case CollectiveOpType::REDUCE_SCATTER_BLOCK:
            case CollectiveOpType::SCAN:
                return true;

            // CASE 2: 1-to-N communication
            case CollectiveOpType::BCAST:
            case CollectiveOpType::SCATTER:
            case CollectiveOpType::SCATTERV:
                return isOnRoot(end, rank);

            // CASE 3: N-to-1 communication
            case CollectiveOpType::GATHER:
            case CollectiveOpType::GATHERV:
            case CollectiveOpType::REDUCE:
                return !isOnRoot(end, rank);

            // SPECIAL CASE:
            // MPI_Alltoallv and MPI_Alltoallw can be used to implement arbitrary
            // communication patterns (e.g., pair-wise message exchange).  However,
            // the trace data currently does not provide enough information for a
            // proper reconstruction, thus, ignore those calls and handle their
            // MPI_COLLECTIVE_END as "internal events".
            //
            // Likewise, handle MPI_COLLECTIVE_END events using other collective
            // operation types in the same way.
            default:
                return false;
        }

        return false;
    }

    if (event->isOfType(GROUP_ENTER))
    {
        const Region& region = event->getRegion();
        if (  is_mpi_init(region)
           || is_mpi_finalize(region))
        {
            return true;
        }

        #if defined(_OPENMP)
            else if (is_omp_barrier(region))
            {
                return true;
            }
        #endif    // _OPENMP

        return false;
    }

    #if defined(_OPENMP)
        if (type == THREAD_FORK)
        {
            return true;
        }

        if (type == THREAD_TEAM_END)
        {
            return true;
        }
    #endif    // _OPENMP

    return false;
}
