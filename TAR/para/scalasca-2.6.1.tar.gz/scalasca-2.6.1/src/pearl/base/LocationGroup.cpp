/****************************************************************************
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2022                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


/*-------------------------------------------------------------------------*/
/**
 *  @file
 *  @ingroup PEARL_base
 *  @brief   Implementation of the class LocationGroup.
 *
 *  This file provides the implementation of the class LocationGroup and
 *  related functions.
 **/
/*-------------------------------------------------------------------------*/


#include <config.h>

#include <pearl/LocationGroup.h>

#include <cassert>
#include <iostream>

#include <UTILS_Error.h>

#include <pearl/String.h>
#include <pearl/SystemNode.h>

#include "iomanip_detail.h"

using namespace std;
using namespace pearl;
using namespace pearl::detail;


// --- Constructors & destructor --------------------------------------------

LocationGroup::LocationGroup(const IdType         id,
                             const String&        name,
                             const Type           type,
                             SystemNode* const    parent,
                             LocationGroup* const creator)
    : mIdentifier(id),
      mName(name),
      mParent(parent),
      mCreator(creator),
      mType(type)
{
    // Dangling location groups are prohibited, except for UNDEFINED
    assert(  parent
          || (  (id == LocationGroup::NO_ID)
             && (name == String::UNDEFINED)
             && (type == LocationGroup::TYPE_UNKNOWN)
             && (creator == 0)));

    if (parent)
    {
        parent->addLocationGroup(this);
    }
}


LocationGroup::~LocationGroup()
{
}


// --- Access definition data -----------------------------------------------

LocationGroup::IdType
LocationGroup::getId() const
{
    return mIdentifier;
}


const String&
LocationGroup::getName() const
{
    return mName;
}


LocationGroup::Type
LocationGroup::getType() const
{
    return mType;
}


SystemNode*
LocationGroup::getParent() const
{
    return mParent;
}


const LocationGroup&
LocationGroup::getCreator() const
{
    if (mCreator == 0)
    {
        return LocationGroup::UNDEFINED;
    }

    return *mCreator;
}


uint32_t
LocationGroup::numLocations() const
{
    return mLocations.size();
}


const Location&
LocationGroup::getLocation(const uint32_t index) const
{
    return *(mLocations.at(index));
}


// --- Stream I/O functions (protected) -------------------------------------

ostream&
LocationGroup::output(ostream& stream) const
{
    stream << "id: " << getId()
           << sep
           << "name: " << getName()
           << sep
           << "type: " << getType()
           << sep
           << "parent: " << *getParent()
           << sep
           << "creator: " << getCreator();

    return stream;
}


// --- Private methods ------------------------------------------------------

/// @brief Add a location.
///
/// Attaches the given @p location to the location group instance.
///
/// @param location
///     %Location to attach (non-NULL)
///
void
LocationGroup::addLocation(Location* const location)
{
    assert(location);
    mLocations.push_back(location);
}


// --- Related functions ----------------------------------------------------

namespace pearl
{
// --- Stream I/O functions --------------------------------

ostream&
operator<<(ostream&             stream,
           const LocationGroup& item)
{
    const long detail = getDetail(stream);

    // Special case: skipped output
    if (detail <= DETAIL_SKIP)
    {
        return stream;
    }

    // Special case: undefined location group
    if (item == LocationGroup::UNDEFINED)
    {
        return stream << "<undef>";
    }

    // Special case: abbreviated output
    if (detail == DETAIL_ABBRV)
    {
        return stream << item.getId();
    }

    // Print data (NOTE: dangling location groups w/o parent are prohibited)
    stream << "LocationGroup"
           << beginObject;
    item.output(stream);
    stream << endObject;

    return stream;
}


ostream&
operator<<(ostream&                  stream,
           const LocationGroup::Type item)
{
    switch (item)
    {
        case LocationGroup::TYPE_UNKNOWN:
            return stream << "unknown";

        case LocationGroup::TYPE_ACCELERATOR:
            return stream << "accelerator";

        case LocationGroup::TYPE_PROCESS:
            return stream << "process";

        default:
            break;
    }

    // Given the switch statement above covers all known cases, we should
    // never get here.  But if we do, we definitely want to know...
    UTILS_BUG("Unknown location group type!");

    return stream;
}


// --- Comparison operators --------------------------------

bool
operator==(const LocationGroup& lhs,
           const LocationGroup& rhs)
{
    // Shortcut: compare addresses
    if (&lhs == &rhs)
    {
        return true;
    }

    return (  (lhs.getId() == rhs.getId())
           && (lhs.getName() == rhs.getName())
           && (lhs.getType() == rhs.getType())
           && (lhs.getParent() == rhs.getParent())
           && (lhs.getCreator() == rhs.getCreator()));
}


bool
operator!=(const LocationGroup& lhs,
           const LocationGroup& rhs)
{
    return !(lhs == rhs);
}
}    // namespace pearl
