/****************************************************************************
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2022                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


/*-------------------------------------------------------------------------*/
/**
 *  @file
 *  @ingroup PEARL_base
 *  @brief   Implementation of the class Process.
 *
 *  This file provides the implementation of the class Process and related
 *  functions.
 **/
/*-------------------------------------------------------------------------*/


#include <config.h>

#include "Process.h"

#include <cassert>
#include <iostream>

#include "iomanip_detail.h"

using namespace std;
using namespace pearl;
using namespace pearl::detail;


// --- Constructors & destructor --------------------------------------------

Process::Process(const IdType         id,
                 const String&        name,
                 SystemNode* const    parent,
                 LocationGroup* const creator)
    : LocationGroup(id, name, LocationGroup::TYPE_PROCESS, parent, creator),
      mRank(-1)
{
}


// --- Access definition data -----------------------------------------------

int
Process::getRank() const
{
    return mRank;
}


// --- Set definition data --------------------------------------------------

void
Process::setRank(int rank)
{
    // Assigned rank numbers need to be >= 0
    assert(rank >= 0);

    mRank = rank;
}


// --- Stream I/O functions (protected) -------------------------------------

ostream&
Process::output(ostream& stream) const
{
    LocationGroup::output(stream);

    stream << sep
           << "rank: " << getRank();

    return stream;
}
