/****************************************************************************
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2022                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


/*-------------------------------------------------------------------------*/
/**
 *  @file
 *  @ingroup PEARL_mpi
 *  @brief   Implementation of the class MpiCollEnd_rep.
 *
 *  This file provides the implementation of the class MpiCollEnd_rep.
 **/
/*-------------------------------------------------------------------------*/


#include <config.h>

#include <pearl/MpiCollEnd_rep.h>

#include <cassert>
#include <iostream>

#include <pearl/Buffer.h>
#include <pearl/CommSet.h>
#include <pearl/GlobalDefs.h>
#include <pearl/MpiComm.h>

#include "iomanip_detail.h"

using namespace std;
using namespace pearl;
using namespace pearl::detail;


// --- Constructors & destructor --------------------------------------------

MpiCollEnd_rep::MpiCollEnd_rep(timestamp_t      timestamp,
                               CollectiveOpType type,
                               MpiComm*         communicator,
                               uint32_t         root,
                               uint64_t         bytesSent,
                               uint64_t         bytesReceived)
    : Event_rep(timestamp),
      mType(type),
      mCommunicator(communicator),
      mRoot(root),
      mBytesSent(bytesSent),
      mBytesReceived(bytesReceived)
{
}


MpiCollEnd_rep::MpiCollEnd_rep(const GlobalDefs& defs,
                               Buffer&           buffer)
    : Event_rep(defs, buffer)
{
    mType          = CollectiveOpType(buffer.get_uint32());
    mCommunicator  = dynamic_cast< MpiComm* >(defs.get_comm(buffer.get_uint32()));
    mRoot          = buffer.get_uint32();
    mBytesSent     = buffer.get_uint64();
    mBytesReceived = buffer.get_uint64();
}


// --- Event type information -----------------------------------------------

event_t
MpiCollEnd_rep::getType() const
{
    return MPI_COLLECTIVE_END;
}


bool
MpiCollEnd_rep::isOfType(event_t type) const
{
    return (  (type == MPI_COLLECTIVE_END)
           || (type == GROUP_END)
           || (type == GROUP_ALL));
}


// --- Access event data ----------------------------------------------------

MpiComm*
MpiCollEnd_rep::getComm() const
{
    return mCommunicator;
}


uint32_t
MpiCollEnd_rep::getRoot() const
{
    return mRoot;
}


uint64_t
MpiCollEnd_rep::getBytesSent() const
{
    return mBytesSent;
}


uint64_t
MpiCollEnd_rep::getBytesReceived() const
{
    return mBytesReceived;
}


CollectiveOpType
MpiCollEnd_rep::getCollType() const
{
    return mType;
}


// --- Serialize event data (protected) -------------------------------------

void
MpiCollEnd_rep::pack(Buffer& buffer) const
{
    Event_rep::pack(buffer);

    buffer.put_uint32(native_value(mType));
    buffer.put_uint32(mCommunicator->getId());
    buffer.put_uint32(mRoot);
    buffer.put_uint64(mBytesSent);
    buffer.put_uint64(mBytesReceived);
}


// --- Generate human-readable output of event data (protected) -------------

ostream&
MpiCollEnd_rep::output(ostream& stream) const
{
    Event_rep::output(stream);

    // Print data
    stream << sep
           << "type: " << mType
           << sep
           << "comm: " << *mCommunicator
           << sep
           << "root: ";
    if (mRoot == PEARL_NO_ID)
    {
        stream << "n/a";
    }
    else
    {
        stream << mRoot
               << " (g: " << mCommunicator->getCommSet().getGlobalRank(mRoot) << ')';
    }
    stream << sep
           << "sent: " << mBytesSent
           << sep
           << "rcvd: " << mBytesReceived;

    return stream;
}
