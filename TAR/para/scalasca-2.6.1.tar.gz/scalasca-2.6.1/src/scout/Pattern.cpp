/****************************************************************************
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2021                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#include <config.h>

#include "Pattern.h"

#include <cstring>

#include <pearl/GlobalDefs.h>
#include <pearl/LocalTrace.h>
#include <pearl/LocationGroup.h>

#include "Patterns_gen.h"
#include "ReportData.h"

#if defined(_MPI)
    #include <mpi.h>
#endif    // _MPI
#if defined(_OPENMP)
    #include <omp.h>
#endif    // _OPENMP

using namespace std;
using namespace pearl;
using namespace scout;


// --- Symbolic names -------------------------------------------------------

#define PATTERNS_URL    "@mirror@scalasca_patterns.html#"


// --- Constructors & destructor --------------------------------------------

/**
 *  @brief Destroys the instance.
 *
 *  Destructor. Destroys the instance and calls the cleanup() member function
 *  to perform pattern-specific data management tasks.
 **/
Pattern::~Pattern()
{
}


// --- Registering callbacks ------------------------------------------------

/**
 *  @brief Registers the pattern-specific replay callbacks.
 *
 *  This method registers the replay callbacks that need to be triggered
 *  during the trace replay for this pattern and calls the init() member
 *  function to perform pattern-specific data management tasks.
 *
 *  @param cbmanager
 *      Map of CallbackManager objects with which the callbacks should be
 *      registered
 **/
void
Pattern::reg_cb(CallbackManagerMap& cbmanagers)
{
    init();
}


// --- Retrieving pattern information ---------------------------------------

/**
 *  @fn    virtual long Pattern::get_id() const
 *  @brief Returns the pattern ID
 *
 *  Returns the numeric identifier associated with this pattern.
 *
 *  @return Pattern ID
 **/


/**
 *  @brief Returns the ID of the parent pattern
 *
 *  Returns the numeric identifier associeted with the parent pattern in the
 *  pattern hierarchy. The default implementation returns PAT_NONE.
 *
 *  @return Parent pattern ID
 **/
long
Pattern::get_parent() const
{
    return PAT_NONE;
}


/**
 *  @fn    virtual std::string Pattern::get_name() const
 *  @brief Returns the pattern name
 *
 *  Returns the display name of the pattern.
 *
 *  @return Pattern name
 **/


/**
 *  @fn    virtual std::string Pattern::get_unique_name() const
 *  @brief Returns the pattern's unique name
 *
 *  Returns the unique name of the pattern which can be used to uniquely
 *  identify a particular pattern.
 *
 *  @return Unique name
 **/


/**
 *  @fn    virtual std::string Pattern::get_descr() const
 *  @brief Returns a brief pattern description
 *
 *  Returns a brief description of the pattern (approximately one line of
 *  text).
 *
 *  @return  Description
 **/


/**
 *  @fn    virtual std::string Pattern::get_unit() const
 *  @brief Returns the pattern's unit of measurement.
 *
 *  Returns the unit of measurement for this pattern. It can be either "sec"
 *  (i.e., seconds), "occ" (i.e., occurrences) or "bytes".
 *
 *  @return Unit of measurement
 **/


/**
 *  @brief Returns the pattern description URL.
 *
 *  Returns the URL where a more detailed description of the pattern can be
 *  found. It is composed of a base URL and the unique name.
 *
 *  @return Description URL
 **/
string
Pattern::get_url() const
{
    return (PATTERNS_URL + get_unique_name());
}


/**
 *  @brief Returns the pattern's visibility.
 *
 *  Returns the external visibility of the pattern. This allows for "internal"
 *  patterns which can define callbacks and store data, but which are not
 *  written to the generated analysis report file.
 *
 *  @return Visibility
 **/
bool
Pattern::is_hidden() const
{
    return false;
}


// --- Writing severity values ----------------------------------------------

/**
 *  @brief Collates the pattern's severities and writes the corresponding
 *         section in the CUBE report.
 *
 *  Generates the severity section of the CUBE report for the pattern.
 *  Therefore, it first collates the values from each process/thread on the
 *  "master node" (the details depend on the parallel programming paradigm
 *  used) and then writes the gathered data to file. This is done incrementally
 *  per call-tree node.
 *
 *  @param  data   Temporary data used for report writing
 *  @param  rank   Global process rank (MPI rank or 0)
 *  @param  trace  Local trace-data object
 *
 *  @todo Fix to deal with non-CPU locations & non-process location groups
 **/
void
Pattern::gen_severities(ReportData&              data,
                        int                      rank,
                        const pearl::LocalTrace& trace)
{
    const pearl::GlobalDefs& defs = trace.get_definitions();

    // --- Determine callpath usage vector and optimal order for writing ---
    const size_t numCallpaths = defs.numCallpaths();
    #pragma omp master
    {
        memset(data.mCallpathUsage, 0, data.mCallpathUsageSize);
    }
    #pragma omp barrier
    for (map< Callpath*, double >::const_iterator it = m_severity.begin();
         it != m_severity.end();
         ++it)
    {
        const Callpath::IdType id   = it->first->getId();
        const uint32_t         byte = id / 8;
        const uint8_t          bit  = 128 >> (id % 8);

        #pragma omp atomic
        data.mCallpathUsage[byte] |= bit;
    }
    #pragma omp barrier
    #pragma omp master
    {
        #if defined(_MPI)
            MPI_Allreduce(MPI_IN_PLACE, data.mCallpathUsage, data.mCallpathUsageSize,
                          SCALASCA_MPI_UINT8_T, MPI_BOR, MPI_COMM_WORLD);
        #endif    // _MPI

        if (rank == 0)
        {
            // Set callpath usage vector
            cube_set_known_cnodes_for_metric(data.cb, data.metrics[get_id()],
                                             reinterpret_cast< char* >(data.mCallpathUsage));

            // Query optimal callpath order for writing
            carray* const callpaths = cube_get_cnodes_for_metric(data.cb,
                                                                 data.metrics[get_id()]);
            for (size_t i = 0; i < numCallpaths; ++i)
            {
                data.mCallpathOrder[i] = static_cast< cube_cnode* >(callpaths->data[i])->id;
            }
        }
        #if defined(_MPI)
            MPI_Bcast(data.mCallpathOrder, numCallpaths,
                      SCALASCA_MPI_UINT32_T, 0, MPI_COMM_WORLD);
        #endif    // _MPI
    }
    #pragma omp barrier

    // --- Collate results ---
    // FIXME: deal with non-CPU locations / non-process groups
    const size_t   numLocations = defs.getLocationGroup(rank).numLocations();
    const uint32_t threadId     = trace.get_location().getThreadId();
    for (size_t i = 0; i < numCallpaths; i++)
    {
        const uint32_t id   = data.mCallpathOrder[i];
        const uint32_t byte = id / 8;
        const uint8_t  bit  = 128 >> (id % 8);

        if ((data.mCallpathUsage[byte] & bit) == 0)
        {
            continue;
        }

        Callpath* const callpath = defs.get_cnode(id);

        // Collate local severities
        #pragma omp barrier
        map< Callpath*, double >::const_iterator it = m_severity.find(callpath);
        data.mLocalSevBuffer[threadId] = (it != m_severity.end())
                                         ? it->second
                                         : 0;
        #pragma omp barrier
        #pragma omp master
        {
            #if defined(_MPI)
                // Gather data from all processes
                if (data.mEqualThreads)
                {
                    MPI_Gather(data.mLocalSevBuffer, numLocations, MPI_DOUBLE,
                               data.mGlobalSevBuffer, numLocations, MPI_DOUBLE,
                               0, MPI_COMM_WORLD);
                }
                else
                {
                    MPI_Gatherv(data.mLocalSevBuffer, numLocations, MPI_DOUBLE,
                                data.mGlobalSevBuffer, data.mRecvCounts, data.mRecvDispls, MPI_DOUBLE,
                                0, MPI_COMM_WORLD);
                }
                MPI_Barrier(MPI_COMM_WORLD);
            #else    // !_MPI
                memcpy(data.mGlobalSevBuffer, data.mLocalSevBuffer,
                       numLocations * sizeof(double));
            #endif    // !_MPI

            if (rank == 0)
            {
                // Write data to file
                cube_write_sev_row_of_doubles(data.cb, data.metrics[get_id()],
                                              data.cnodes[callpath->getId()],
                                              data.mGlobalSevBuffer);
            }
        }
    }

    // Synchronize threads to avoid data races in reused data fields
    #pragma omp barrier
}


// --- Pattern management ---------------------------------------------------

/**
 *  @brief Initializes local data.
 *
 *  This method can be overwritten in derived classes to initialize local
 *  data. The default implementation is empty.
 **/
void
Pattern::init()
{
}
