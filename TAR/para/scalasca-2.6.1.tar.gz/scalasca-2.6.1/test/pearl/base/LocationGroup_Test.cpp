/****************************************************************************
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2019-2022                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


#include <config.h>

#include <pearl/LocationGroup.h>

#include <iostream>

#include <gtest/gtest.h>

#include <pearl/String.h>
#include <pearl/SystemNode.h>
#include <pearl/iomanip.h>

#include "iomanip_detail.h"

using namespace std;
using namespace testing;
using namespace pearl;
using namespace pearl::detail;


// --- Helper ---------------------------------------------------------------

namespace
{
// Test fixture for LocationGroup tests
class LocationGroupT
    : public Test
{
    public:
        LocationGroupT();


    protected:
        const String  mParentName;
        const String  mParentClass;
        SystemNode    mParent;
        const String  mName;
        LocationGroup mCreator;
        LocationGroup mItem;
};
}    // unnamed namespace


// --- LocationGroup tests --------------------------------------------------

TEST_F(LocationGroupT,
       operatorLeftShift_undefinedAtSkipDetail_printsNothing)
{
    string expected;

    ostringstream result;
    result << setDetail(DETAIL_SKIP)
           << LocationGroup::UNDEFINED;
    EXPECT_EQ(expected, result.str());
}


TEST_F(LocationGroupT,
       operatorLeftShift_itemAtSkipDetail_printsNothing)
{
    string expected;

    ostringstream result;
    result << setDetail(DETAIL_SKIP)
           << mItem;
    EXPECT_EQ(expected, result.str());
}


TEST_F(LocationGroupT,
       operatorLeftShift_undefinedAtAbbrvDetail_printsUndef)
{
    string expected("<undef>");

    ostringstream result;
    result << setDetail(DETAIL_ABBRV)
           << LocationGroup::UNDEFINED;
    EXPECT_EQ(expected, result.str());
}


TEST_F(LocationGroupT,
       operatorLeftShift_itemAtAbbrevDetail_printsIdentifier)
{
    string expected("42");

    ostringstream result;
    result << setDetail(DETAIL_ABBRV)
           << mItem;
    EXPECT_EQ(expected, result.str());
}


TEST_F(LocationGroupT,
       operatorLeftShift_undefinedAtCompactDetail_printsUndef)
{
    string expected("<undef>");

    ostringstream result;
    result << LocationGroup::UNDEFINED;
    EXPECT_EQ(expected, result.str());
}


TEST_F(LocationGroupT,
       operatorLeftShift_itemAtCompactDetail_printsOneliner)
{
    string expected("LocationGroup { id: 42, name: \"Group 42\", type: unknown, parent: 0, creator: 24 }");

    ostringstream result;
    result << mItem;
    EXPECT_EQ(expected, result.str());
}


TEST_F(LocationGroupT,
       operatorLeftShift_undefinedAtFullDetail_printsUndef)
{
    string expected("<undef>");

    ostringstream result;
    result << setDetail(DETAIL_FULL)
           << LocationGroup::UNDEFINED;
    EXPECT_EQ(expected, result.str());
}


TEST_F(LocationGroupT,
       operatorLeftShift_itemAtFullDetail_printsData)
{
    string expected("LocationGroup {\n"
                    "    id: 42\n"
                    "    name: String { id: 2, text: \"Group 42\" }\n"
                    "    type: unknown\n"
                    "    parent: SystemNode { id: 0, name: \"blade\", class: \"node\", parent: <undef> }\n"
                    "    creator: LocationGroup { id: 24, name: <undef>, type: unknown, parent: 0, creator: <undef> }\n"
                    "}");

    ostringstream result;
    result << setDetail(DETAIL_FULL)
           << mItem;
    EXPECT_EQ(expected, result.str());
}


// --- Helper ---------------------------------------------------------------

/// @todo[C++11] Use `nullptr` instead of `NULL`
LocationGroupT::LocationGroupT()
    : mParentName(0, "blade"),
      mParentClass(1, "node"),
      mParent(0, mParentName, mParentClass, NULL),
      mName(2, "Group 42"),
      mCreator(24, String::UNDEFINED, LocationGroup::TYPE_UNKNOWN, &mParent, NULL),
      mItem(42, mName, LocationGroup::TYPE_UNKNOWN, &mParent, &mCreator)
{
}
